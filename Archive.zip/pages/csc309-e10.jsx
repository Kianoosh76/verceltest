export default function handler(){
	return (
		<div id="auto-tester">
			  Hi. I am abbasiki, and I have learned how to develop a full-stack web app and
  deploy it!
		</div>
	)
}
